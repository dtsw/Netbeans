<?php

/* default/new.html.twig */
class __TwigTemplate_42af31dafc45c1b935e2d49a14e22b5aed85ee4c53715f133f6100a24a3c4208 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_355f7734e09d4221df166204d21280a889f475b64a7c8867a2a6df87cee597a1 = $this->env->getExtension("native_profiler");
        $__internal_355f7734e09d4221df166204d21280a889f475b64a7c8867a2a6df87cee597a1->enter($__internal_355f7734e09d4221df166204d21280a889f475b64a7c8867a2a6df87cee597a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/new.html.twig"));

        // line 1
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 2
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 3
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

";
        
        $__internal_355f7734e09d4221df166204d21280a889f475b64a7c8867a2a6df87cee597a1->leave($__internal_355f7734e09d4221df166204d21280a889f475b64a7c8867a2a6df87cee597a1_prof);

    }

    public function getTemplateName()
    {
        return "default/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  26 => 2,  22 => 1,);
    }
}
/* {{ form_start(form) }}*/
/* {{ form_widget(form) }}*/
/* {{ form_end(form) }}*/
/* */
/* */
