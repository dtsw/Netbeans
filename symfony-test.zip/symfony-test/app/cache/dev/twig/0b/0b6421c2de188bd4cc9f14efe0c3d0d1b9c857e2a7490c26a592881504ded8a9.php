<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_3206cbe23ef385192ea29c79d2c7b1e4fbdd3329ed6e3e5dbef801f5065d680e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f7aa77696b87c7e0fd0133bb810e1e94bb29b8b81fc0cb1302c8e0884dbae91 = $this->env->getExtension("native_profiler");
        $__internal_0f7aa77696b87c7e0fd0133bb810e1e94bb29b8b81fc0cb1302c8e0884dbae91->enter($__internal_0f7aa77696b87c7e0fd0133bb810e1e94bb29b8b81fc0cb1302c8e0884dbae91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0f7aa77696b87c7e0fd0133bb810e1e94bb29b8b81fc0cb1302c8e0884dbae91->leave($__internal_0f7aa77696b87c7e0fd0133bb810e1e94bb29b8b81fc0cb1302c8e0884dbae91_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_1dab1471859110e8b0e562a964c3ed159a0fbb5fb8ddad07768a2918c496fa64 = $this->env->getExtension("native_profiler");
        $__internal_1dab1471859110e8b0e562a964c3ed159a0fbb5fb8ddad07768a2918c496fa64->enter($__internal_1dab1471859110e8b0e562a964c3ed159a0fbb5fb8ddad07768a2918c496fa64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_1dab1471859110e8b0e562a964c3ed159a0fbb5fb8ddad07768a2918c496fa64->leave($__internal_1dab1471859110e8b0e562a964c3ed159a0fbb5fb8ddad07768a2918c496fa64_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c045f893f35463a917ce8a15fb33000d05dc4af29037b37a1c49841342f4562d = $this->env->getExtension("native_profiler");
        $__internal_c045f893f35463a917ce8a15fb33000d05dc4af29037b37a1c49841342f4562d->enter($__internal_c045f893f35463a917ce8a15fb33000d05dc4af29037b37a1c49841342f4562d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_c045f893f35463a917ce8a15fb33000d05dc4af29037b37a1c49841342f4562d->leave($__internal_c045f893f35463a917ce8a15fb33000d05dc4af29037b37a1c49841342f4562d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_70a7fdfa3950fbb82f8afbba43316e1e74634566af9f1ac3d0b3c44381d3673c = $this->env->getExtension("native_profiler");
        $__internal_70a7fdfa3950fbb82f8afbba43316e1e74634566af9f1ac3d0b3c44381d3673c->enter($__internal_70a7fdfa3950fbb82f8afbba43316e1e74634566af9f1ac3d0b3c44381d3673c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_70a7fdfa3950fbb82f8afbba43316e1e74634566af9f1ac3d0b3c44381d3673c->leave($__internal_70a7fdfa3950fbb82f8afbba43316e1e74634566af9f1ac3d0b3c44381d3673c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
