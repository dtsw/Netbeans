<?php

namespace AppBundle\Entity;

class Task
{
	protected $demo;
	protected $task;
	protected $dueDate;

	public function getDemo()
	{
		return $this->demo;
	}

	public function setDemo($demo)
	{
		$this->demo = $demo;
	}

	public function getTask()
	{
		return $this->task;
	}

	public function getDueDate()
	{
		return $this->dueDate;
	}

	public function setTask($task)
	{
		$this->task = $task;
	}

	public function setDueDate(\DateTime $dueDate = null)
	{
		$this->dueDate = $dueDate;
	}
}
