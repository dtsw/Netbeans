<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Task;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

	/**
	* @Route("/form_success", name="task_success")
	*/
	public function successAction(Request $request)
	{
		var_dump($request);
		return new Response("OK");
	}

	/**
	* @Route("/form_new", name="form_new")
	*/
	public function newAction(Request $request)
	{
		$task = new Task();
		$task->setTask('Write a blog post');
		$task->setDueDate(new \DateTime('tomorrow'));

$form = $this->createFormBuilder($task)
	    ->add('demo', null, array('attr' => array('maxlength' => 4, 'required' => '')))
            ->add('task', 'Symfony\Component\Form\Extension\Core\Type\TextType')
            ->add('dueDate', 'Symfony\Component\Form\Extension\Core\Type\DateType')
            ->add('save', 'Symfony\Component\Form\Extension\Core\Type\SubmitType', array('label' => 'Create Post'))
            ->getForm();

		$form->handleRequest($request);
		if ($form->isSubmitted() && $form->isValid()) {
        		// $form->getData() holds the submitted values
        		// but, the original `$task` variable has also been updated
        		$task = $form->getData();
			// perform some action
			var_dump($task);
			//return $this->redirectToRoute('task_success');
		}
		return $this->render('default/new.html.twig', array(
			'form' => $form->createView(),
		));
	}

}
